<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <link rel="stylesheet" href="css/style.css" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Reenie+Beanie" rel="stylesheet">
    <title>_botanica_Studio_THANKS</title>
    
</head>
   
    <body>
              
              <style>
                A:link    {text-decoration:none; color: black}
                A:visited {text-decoration:none; color: black}
		      </style>
              
               <div class="GoodBye_Box">
               
               <p class="thankYouText">Thank you for choosing</p>
               
               <h1 class="checkoutH1" ><a href="index.php" style="text-decoration: none">___botánica_Studio__&#9729;______</a></h1>
               
               <img src="image/rose.png" alt="ThankYou">
            
               </div>
    
    </body>

</html>