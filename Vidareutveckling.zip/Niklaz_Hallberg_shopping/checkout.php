<?php
session_start();

$print1_price = 400;
$print2_price = 500;
$print3_price = 600;
$print4_price = 700;

$day = "sunday";

 if ($day == "monday"){
            $print1_price = ($print1_price) / 2;
            $print2_price = ($print2_price) / 2;
            $print3_price = ($print3_price) / 2;
            $print4_price = ($print4_price) / 2;
        } else if ($day == "wednesday"){
             $print1_price = ($print1_price) * 1.1;
             $print2_price = ($print2_price) * 1.1;
             $print3_price = ($print3_price) * 1.1;
             $print4_price = ($print4_price) * 1.1;
        } else if ($day == "friday"){
            if ($print1_price > 200){
                $print1_price = $print1_price - 20;
                } 
            if ($print2_price > 200){
                $print2_price = $print2_price - 20;
                } 
            if ($print3_price > 200){
                $print3_price = $print3_price - 20;
                } 
            if ($print4_price > 200){
                $print4_price = $print4_price - 20;
                } 
 }

if (empty($_POST["firstName"] )){
    header('Location: /index.php?error=Oups! You forgot to enter your firstname.');
}
 else if (empty($_POST["lastName"])){
    header('Location: /index.php?error=Oups! You forgot to enter your lastName.');

} else if (empty($_POST["Adress"])){
    header('Location: /index.php?error=Oups! You forgot to enter your adress.');
    
} else if (empty($_POST["ZipCode"])){
    header('Location: /index.php?error=Oups! You forgot to enter your zipcode.');
    
} else if (empty($_POST["Phone"])){
    header('Location: /index.php?error=Oups! You forgot to enter your phone number.');
    
} else if (empty($_POST["Mail"])){
    header('Location: /index.php?error=Oups! You forgot to enter your mail!.');
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <link rel="stylesheet" href="css/style.css" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Ubuntu+Mono" rel="stylesheet">
    <title>CHECKOUT</title>
</head>

<body>



    <div class="container">

        <section class="row" role="region">

            <div class="col-md-6 information_box">

                <!-- CONTACT INFORMATION -->

                <h2>Your information</h2>

                <? if(isset($_POST["firstName"])){
        $_SESSION["firstName"] = $_POST ["firstName"];
			echo $_SESSION["firstName"];
}
    
if(isset($_POST["lastName"])){
    $_SESSION["lastName"] = $_POST ["lastName"];
			echo $_SESSION["lastName"];
}
        
if(isset($_POST["Adress"])){
    $_SESSION["Adress"] = $_POST ["Adress"];
			echo $_SESSION["Adress"];
}
            
if(isset($_POST["ZipCode"])){
    $_SESSION["ZipCode"] = $_POST ["ZipCode"];
			echo $_SESSION["ZipCode"];
}
                
if(isset($_POST["Phone"])){
    $_SESSION["Phone"] = $_POST ["Phone"];
			echo $_SESSION["Phone"];
}
                    
if(isset($_POST["Mail"])){
    $_SESSION["Mail"] = $_POST ["Mail"];
			echo $_SESSION["Mail"];
}
    
?>

            </div>

            <div class="col-md-6">

                <!-- BUY LISTS DOWN BELOW -->

                <p> You're about to buy: </p>

    <?php
                
        // UTRÄKNING, PRODUKT - PRIS - ANTAL OCH TOTALT SUM.
                
              
        
        if(isset($_POST["quantityCremnophila_nutans"])){
        $_SESSION["quantityCremnophila_nutans"] = $_POST["quantityCremnophila_nutans"];
            
        $total1 = ($print1_price * $_SESSION["quantityCremnophila_nutans"]);
        
            echo ' Cremnophila nutans ' . ' - ' . $print1_price . ' sek/pcs ' . ' - ' . $_SESSION["quantityCremnophila_nutans"] . ' pcs ' . ' and sum: ' . $total1 . ' sek ';
            
        }
                
        if(isset($_POST["quantityOthonna_Crassifolia"])){
        $_SESSION["quantityOthonna_Crassifolia"] = $_POST ["quantityOthonna_Crassifolia"];
        
        $total2 = ($print2_price * $_SESSION["quantityOthonna_Crassifolia"]);
        echo ' Othonna Crassifolia ' . ' - ' . $print2_price . ' sek/pcs ' . ' - ' . $_SESSION["quantityOthonna_Crassifolia"] . ' pcs ' . ' and sum: ' . $total2 . ' sek ';
            
        }
            
        if(isset($_POST["quantitySymphoricarpos_albus"])){
        $_SESSION["quantitySymphoricarpos_albus"] = $_POST ["quantitySymphoricarpos_albus"];
            
        $total3 = ($print3_price * $_SESSION["quantitySymphoricarpos_albus"]);
        echo ' Symphoricarpos albus ' . ' - ' . $print3_price . ' sek/pcs ' . ' - ' . $_SESSION["quantitySymphoricarpos_albus"] . ' pcs ' . ' and sum: ' . $total3 . ' sek ';
            
        }
            
        if(isset($_POST["quantityVerticillata"])){
        $_SESSION["quantityVerticillata"] = $_POST ["quantityVerticillata"];
            
        $total4 = ($print4_price * $_SESSION["quantityVerticillata"]);
        echo ' Verticillata ' . ' - ' . $print4_price . ' sek/pcs ' . ' - ' . $_SESSION["quantityVerticillata"] . ' pcs ' . ' and sum: ' . $total4 . ' sek ';
            
        }
        
// NEDAN MÅSTE FIXAS!
                
      // $_SESSION["total_quantity"] = $_SESSION["quantity1"] + $_SESSION["quantity2"] + $_SESSION["quantity3"] + $_SESSION["quantity4"];
                
       /* // WEEKDAY PRICE CORRECTION
        
        if ($day == "monday"){
            $totalsum = ($total1+$total2+$total3+$total4) / 2;
            echo ' Total sum: ' . $totalsum . ' sek. '; 
        } else if ($day == "wednesday"){
            $totalsum = ($total1+$total2+$total3+$total4) * 3;
            echo ' Total sum: ' . $totalsum . ' sek. ';
        } else if ($day == "friday"){
            //for(i=0; i < $_SESSION["total_quantity"]; i++)
            if ($print1_price > 200){
                $print1_price = $print1_price - 20;
            }
                
            $totalsum = ($total1+$total2+$total3+$total4) - 200;
            echo ' Total sum: ' . $totalsum . ' sek. ';
        } else { 
           $totalsum = ($total1+$total2+$total3+$total4); 
                echo ' Total sum: ' . $totalsum . ' sek. ';       
        }
        */
                
     //$totalsum = ($total1+$total2+$total3+$total4); 
            //    echo ' Total sum: ' . $totalsum . ' sek. ';  
                
                

                ?>
            </div>

        </section>

    </div>

</body>

</html>
