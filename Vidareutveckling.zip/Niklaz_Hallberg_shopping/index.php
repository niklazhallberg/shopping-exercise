<?php
session_start();

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <link rel="stylesheet" href="css/style.css" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Ubuntu+Mono" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Anonymous+Pro" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Reenie+Beanie" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Kristi|La+Belle+Aurore|Mr+De+Haviland" rel="stylesheet">

    <title>_botanica_Visuals_</title>
</head>

<body>
    
    <h1>___botánica_Studio__&#9729;______</h1>

    <p class="rotate"> About us </p>
    
    
    <!-- both Action and method must exist -->
    
    <div class="container text-center">
    
    <section class="row" role="region">
       
            <?php
                        
                $all_prints = ["Cremnophila nutans", "Othonna Crassifolia", "Symphoricarpos albus", "Verticillata"];
            
                $all_prints = [
  [
    "name" => "Cremnophila_nutans",
    "price" => "400",
    "image" => "image/blomma1.png"
  ],
  [
    "name" => "Othonna_Crassifolia",
    "price" => "500",
    "image" => "image/blomma2.png"
  ],
  [
  "name" => "Symphoricarpos_albus",
    "price" => "600",
    "image" => "image/blomma3.png"
  ],
  [
  "name" => "Verticillata",
    "price" => "700",
    "image" => "image/blomma4.png"
  ]
  
];
                        
?>
            <div class="col-12">
            
          <?php 
                
              foreach($all_prints as $single_print): ?>
            
            <div class="flower_box">
              
               <img src="<?= $single_print["image"]; ?>"/>
               <p><?= $single_print["name"]; ?></p>
               <p><?= $single_print["price"]; ?> sek</p>
               <label for="quantity">Qty</label>
               
            </div>
                 <input size="1" id= "quantity" name="quantity<?= $single_print["name"]?>" type="number" placeholder= "0" form="form1"/>

                <?php endforeach; ?>
                        
                    <!--    
                        <p>Cremnophila nutans</p>
                        <p>Price: 400 sek</p>
                        <p>Quantity: <input form="form1" type="text" name="quantity1" size="2" /></p><p><i>(few in stock)</i></p> 
                        -->
                        
                    </div>
                    
                    <div class="col-12">
                       
                      <!--  <img src="image/blomma2.png">
                        <p>Othonna Crassifolia</p>
                        <p>Price: 400 sek</p>
                        <p>Quantity: <input form="form1" type="text" name="quantity2" size="2" /></p>
                    </div>
                    
                    -->
                    
                    <div class="col-12">
                    
                  <!--  <img src="image/blomma3.png">
                        <p>Symphoricarpos albus</p>
                        <p>Price: 450 sek</p>
                        <p>Quantity: <input form="form1" type="text" name="quantity3" size="2" /></p>
                        -->
                        
                    </div>
                    
                    <div class="col-12">
                       <!--
                        <img src="image/blomma4.png">
                        <p>Verticillata</p>
                        <p>Price: 500 sek</p>
                        <p>Quantity: <input form="form1" type="text" name="quantity4" size="2" /></p>
                        -->
                        
                    </div>
                    
                    

                </section>
            
    <div class="contactform">
    
    <p class="Customer_info"><b>Fill form below :)</b></p>
    
    <form action="checkout.php" method="POST" class="form" id="form1">
        <label for="firstName">First name: </label>
        <input id="firstName" type="text" name="firstName" /><br>
        <label for="lastName">Last name: </label>
        <input id="lastName" type="text" name="lastName"/><br>
        <label for="Adress">Adress: </label>
        <input id="Adress" type="text" name="Adress"/><br>
        <label for="ZipCode">Zipcode: </label>
        <input id="ZipCode" type="text" name="ZipCode"/><br>
        <label for="Phone">Phone: </label>
        <input id="Phone" type="text" name="Phone" /><br>
        <label for="Mail">Mail: </label>
        <input id="Mail" type="text" name="Mail"  /><br>
        <input type="submit" value="Checkout"/> 
    </form>
    
<?php
   if (isset($_GET["error"])){
       echo $_GET["error"];
   }
?>

</div>
   
</div>
    
</body>

</html>